var express = require('express');
var http = require('http');

var app = express();
app.use('/', express.static(__dirname));

var httpPort = 8000;
http.createServer(app).listen(httpPort, function(){
  console.log("HTTP server listening on port %s", httpPort);
});
